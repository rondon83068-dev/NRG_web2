# NRG Command Dashboard

A responsive, dark-red (#8B0000) dashboard prototype for designing Discord embeds and preparing auto-post rules for the National Register Guard.

## Included
- Overview and local activity log
- Live Discord-style embed preview
- Save, load, and delete embed drafts in the current browser
- Copy an embed payload as Discord webhook-compatible JSON
- Save local auto-post rule drafts and message-trigger settings
- General bot command reference
- Camel integration checklist and copyable request prompt
- Responsive layout for Android/mobile and desktop

## Important: current integration status
This is a front-end prototype. It does **not** send messages to Discord, invoke Camel commands, or run scheduled posts. Drafts are saved in the browser's `localStorage` on that device. Auto-posting requires a real server-side integration/scheduler. Do not place a Discord bot token or webhook secret in `app.js`, HTML, GitHub Pages, or a public repository.

## Publish for free with GitHub Pages (Android)
1. Download and unzip `NRG_Command_Dashboard.zip`.
2. Create a GitHub repository, for example `NRG-Command-Dashboard`.
3. Upload `index.html`, `styles.css`, `app.js`, and this README to the repository root (not inside an extra nested folder).
4. In the repository, open **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/(root)`, then Save.
6. Wait for GitHub Pages to publish. Open the provided Pages URL.
7. Test the embed builder, save draft, copy JSON, and mobile menu.

## Connect the Camel bot later
1. In Camel, ask its AI builder/support whether your published bot can receive inbound authenticated HTTPS requests. The dashboard has a **Copy Camel request** button with a detailed prompt.
2. Use only the endpoint details Camel actually confirms. Never guess the endpoint.
3. If Camel supports inbound requests, use a separate backend to authenticate website users and call Camel. Keep credentials in backend environment variables.
4. If Camel cannot receive inbound requests, a Discord channel webhook can post embeds to one configured channel, but it is not equivalent to controlling the bot or reading message events. Keep its URL on a backend, not in the browser.
5. Browser-side schedules are not reliable. Run recurring jobs in a server-side scheduler and include permission checks, rate limits, cooldowns, duplicate protection, and anti-loop logic.
6. Do not paste your bot token, API keys, or full webhook URL into chat.

## Files
- `index.html` — page layout
- `styles.css` — responsive visual design
- `app.js` — local preview, browser-only storage, and interactions
